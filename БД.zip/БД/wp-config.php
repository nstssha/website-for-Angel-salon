<?php
define( 'WP_CACHE', true );

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'L1bf.eu5}=?s8#H/hjD|1#%5SMQme;IY?>H5 om9vSQFn(anMf5D0`b<GaX*/3@2' );
define( 'SECURE_AUTH_KEY',   'N_$W.azZ!, iSFeLDEUV;^GiJ+1#l#+h>x=mK6.$HW$bKp.lxhDHS|.)nZc^oKf}' );
define( 'LOGGED_IN_KEY',     '#zA<7(<+TgT/xo#)SGIk>9%,qnRX1@|CZ@Vv3rE(Ba8h9VQ`Dw:G_JY-+hWacfr$' );
define( 'NONCE_KEY',         '8!#_`XFjBIR$(C0&3d?=#X~_wJ]hyBAsJ^9eD|*8mzTX5O,h`#I4Mv@JU^C<lHYM' );
define( 'AUTH_SALT',         '-+L2m<b2P9P[=kO6dmt,sDObMp_B[Ft?.}.6rbI:<+Ng%sY4:< EIVEA6G!Z]MpX' );
define( 'SECURE_AUTH_SALT',  '*H6nI<k8GlwVl9)l0H>?LeCQbBw|z<6tv7@Y3 Kt#/L_Z<CZ[zy=H9*L)-AxhGRH' );
define( 'LOGGED_IN_SALT',    'ciSNjL=WPbf>$}OH(Hnw.GcWUR$dJgg4wxbURbl[I4=kA&|589R(]J.AA+_>|i[[' );
define( 'NONCE_SALT',        'My-&aEffci)|H>?N),-;r?0@UP{/o=s<`:,>K3Bf|!985`jvNrI1+)1qg4h|8^3B' );
define( 'WP_CACHE_KEY_SALT', '!L_E@$&bd=RSz8x!M3 MHd0~E[5,1,V1rp;`|6SfJ0CF>H$(el}_Z5.p5z+4OHgt' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );

define( 'WP_MEMORY_LIMIT', '256M' );
define( 'WP_MAX_MEMORY_LIMIT', '512M' );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
